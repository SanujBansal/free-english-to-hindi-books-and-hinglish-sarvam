import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { presignDownload, putObject, s3Keys } from "@/lib/s3";
import { BULBUL_SPEAKERS, textToSpeech } from "@/lib/sarvam";
import { simplifyToHinglish, type SimplifyStyle } from "@/lib/simplify";
import type { SpeakResponse } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

/**
 * Give me the audio for one segment.
 *
 * Fully cached: the Hinglish rewrite is stored on the Segment row, the rendered
 * WAV in S3 keyed by (segment, speaker). A second listener on the same book
 * pays nothing — no LLM call, no TTS call, just a presigned URL.
 */
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const segmentId = String(body?.segmentId ?? "").trim();
  if (!segmentId) return NextResponse.json({ error: "segmentId is required" }, { status: 400 });

  const segment = await prisma.segment.findUnique({
    where: { id: segmentId },
    include: { book: { select: { id: true, title: true, enabled: true, status: true, simplifyStyle: true, defaultSpeaker: true } } },
  });

  if (!segment || !segment.book.enabled || segment.book.status !== "ready") {
    return NextResponse.json({ error: "Segment not available" }, { status: 404 });
  }

  const requested = String(
    body?.speaker ?? (segment.book.defaultSpeaker || "shubh"),
  ).toLowerCase();
  const speaker = (BULBUL_SPEAKERS as readonly string[]).includes(requested)
    ? requested
    : segment.book.defaultSpeaker;

  // 1. Already rendered in this voice?
  const cached = await prisma.audio.findUnique({
    where: { segmentId_speaker: { segmentId, speaker } },
  });

  if (cached && segment.hinglishText) {
    const audioUrl = await presignDownload(cached.s3Key);
    return NextResponse.json<SpeakResponse>({
      segmentId,
      audioUrl,
      hinglishText: segment.hinglishText,
      sourceText: segment.sourceText,
      speaker,
      cached: true,
    });
  }

  try {
    // 2. Rewrite into easy Hinglish (cached on the segment after the first listener).
    let hinglishText = segment.hinglishText;

    if (!hinglishText) {
      const chapter = await prisma.chapter.findFirst({
        where: {
          bookId: segment.bookId,
          startPage: { lte: segment.pageNumber },
          endPage: { gte: segment.pageNumber },
        },
        select: { title: true },
      });

      const previous =
        segment.index > 0
          ? await prisma.segment.findUnique({
              where: { bookId_index: { bookId: segment.bookId, index: segment.index - 1 } },
              select: { sourceText: true },
            })
          : null;

      hinglishText = await simplifyToHinglish(
        segment.sourceText,
        segment.book.simplifyStyle as SimplifyStyle,
        {
          bookTitle: segment.book.title,
          chapterTitle: chapter?.title,
          previousTail: previous?.sourceText.slice(-300),
        },
      );

      await prisma.segment.update({
        where: { id: segmentId },
        data: { hinglishText, status: "pending", error: null },
      });
    }

    // 3. Narrate it.
    const { wav, sampleRate } = await textToSpeech({
      text: hinglishText,
      languageCode: "hi-IN",
      speaker,
    });

    const key = s3Keys.audio(segment.bookId, segmentId, speaker);
    await putObject(key, wav, "audio/wav");

    await prisma.audio.upsert({
      where: { segmentId_speaker: { segmentId, speaker } },
      create: { segmentId, speaker, s3Key: key, bytes: wav.length, sampleRate },
      update: { s3Key: key, bytes: wav.length, sampleRate },
    });

    await prisma.segment.update({
      where: { id: segmentId },
      data: { status: "ready", error: null },
    });

    const audioUrl = await presignDownload(key);

    return NextResponse.json<SpeakResponse>({
      segmentId,
      audioUrl,
      hinglishText,
      sourceText: segment.sourceText,
      speaker,
      cached: false,
    });
  } catch (error) {
    const message = (error as Error).message ?? "Narration failed";
    await prisma.segment
      .update({ where: { id: segmentId }, data: { status: "failed", error: message.slice(0, 500) } })
      .catch(() => undefined);
    return NextResponse.json({ error: message }, { status: 502 });
  }
}
