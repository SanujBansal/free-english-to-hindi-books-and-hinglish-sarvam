/**
 * Turns a slice of English book text into easy spoken Hinglish (or simple Hindi)
 * using sarvam-105b, then hands the result to bulbul:v3 for narration.
 *
 * Why an LLM and not /translate: a faithful translation of an English book is
 * still hard for someone with weak English *and* weak formal Hindi — the ideas
 * stay abstract. The LLM pass is allowed to unpack a sentence, swap a hard word
 * for a common one, and keep everyday English words (school, computer, market)
 * that Indian readers already know.
 */
import { chatComplete } from "./sarvam";

export type SimplifyStyle = "hinglish" | "hindi";

const HINGLISH_SYSTEM = `You convert passages from English books into easy spoken Hinglish for Indian listeners who understand little English.

Rules:
- Write in Devanagari script.
- Use everyday spoken Hindi, the way a friend explains something out loud.
- Keep common English words that Indians already use daily (स्कूल, कंपनी, कंप्यूटर, मार्केट, टीम, प्रोजेक्ट) in Devanagari. Do not force rare Sanskritised Hindi words.
- If the passage contains a difficult idea, term or metaphor, explain it in one short extra sentence in simple words.
- Keep every name, number, date and quantity exactly as in the original.
- Keep the author's meaning and order. Do not add opinions, do not summarise away content, do not skip sentences.
- Break long English sentences into short spoken sentences.
- Output ONLY the rewritten passage. No preamble, no headings, no markdown, no notes, no quotation marks around the whole output.
- The output will be read aloud by a text-to-speech voice, so avoid symbols like *, #, _, brackets and footnote markers. Spell out abbreviations the first time.`;

const HINDI_SYSTEM = `You convert passages from English books into simple, clear Hindi for listeners with little English.

Rules:
- Write in Devanagari script using simple, commonly understood Hindi.
- Avoid heavy Sanskritised vocabulary; prefer the word an ordinary speaker would use.
- If a difficult idea or term appears, explain it in one short extra sentence.
- Keep every name, number, date and quantity exactly as in the original.
- Preserve the author's meaning and order. Do not summarise or skip content.
- Output ONLY the rewritten passage. No preamble, headings, markdown or notes.
- The output will be read aloud, so avoid symbols like *, #, _ and footnote markers.`;

export function systemPromptFor(style: SimplifyStyle): string {
  return style === "hindi" ? HINDI_SYSTEM : HINGLISH_SYSTEM;
}

/** Strip the wrappers an LLM sometimes adds despite instructions. */
export function cleanModelOutput(raw: string): string {
  let text = raw.trim();

  // Fenced code block
  const fence = text.match(/^```[a-zA-Z]*\n([\s\S]*?)\n```$/);
  if (fence) text = fence[1].trim();

  // Leading "Here is the ...:" style preamble in English before Devanagari starts
  const devanagariStart = text.search(/[ऀ-ॿ]/);
  if (devanagariStart > 0) {
    const before = text.slice(0, devanagariStart);
    if (/^[^ऀ-ॿ]{0,160}$/.test(before) && /[:\-\n]\s*$/.test(before)) {
      text = text.slice(devanagariStart);
    }
  }

  return text
    .replace(/^["'«]|["'»]$/g, "")
    .replace(/[*_#]+/g, "")
    .replace(/[ \t]+/g, " ")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

/**
 * @param text        one segment of the original English book text
 * @param style       hinglish (default) or hindi
 * @param context     optional: book title / chapter title, helps with pronouns and jargon
 */
export async function simplifyToHinglish(
  text: string,
  style: SimplifyStyle = "hinglish",
  context?: { bookTitle?: string; chapterTitle?: string; previousTail?: string },
): Promise<string> {
  const contextLines: string[] = [];
  if (context?.bookTitle) contextLines.push(`Book: ${context.bookTitle}`);
  if (context?.chapterTitle) contextLines.push(`Chapter: ${context.chapterTitle}`);
  if (context?.previousTail) {
    contextLines.push(
      `End of the previous passage (for continuity only — do NOT re-translate it):\n${context.previousTail}`,
    );
  }

  const user = [
    contextLines.join("\n"),
    contextLines.length ? "\n---\n" : "",
    "Rewrite this passage:\n\n",
    text,
  ].join("");

  const raw = await chatComplete(
    [
      { role: "system", content: systemPromptFor(style) },
      { role: "user", content: user },
    ],
    { temperature: 0.3, maxTokens: 2048 },
  );

  const cleaned = cleanModelOutput(raw);
  if (!cleaned) throw new Error("Simplification returned empty text");
  return cleaned;
}
